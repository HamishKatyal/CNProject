# Online-Quiz-website-test-your-knowledge- #
My project of Web development, a quiz website on which there will be questions on different topics. This project is choosen by me as my college project for INT219'
( Frontend Web developer )
<br />you can see this website live on Laptop or desktop mode [let's go to INT219 quiz website click here](http://int219quiz.surge.sh)
<br />
<br />
## --------------------------------Have a overview how it looks----------------------------------- ##
![](int219_ca3.gif)
## ---------------------------Three Benefits of Quizzes in e-Learning------------------------- ##

When it comes to testing, training professionals have a dilemma. “With all the focus on determining whether training helps people perform better, do we really need to include multiple choice quizzes in our e-learning? Don’t multiple choice quizzes insult the intelligence of our learners who are experienced, smart, adult learners who do not want to be treated like school children? I mean, I know that we want people to learn what is in the training and testing is a way to do that. But do these quizzes really do anything for anyone?”


The answer is a resounding, “Yes.”

Much research has been conducted to determine the benefits of tests, quizzes, and assessments in training. Most of this research points to several benefits that learning experience (LX) designers should understand. One example is from a 2010 study which concluded that testing requires learners to “retrieve information effortfully from memory, and that such effortful retrieval turns out to be a wonderfully powerful mnemonic device in many circumstances.” In a recent Richardson blog post, assessments can be used not only to test what people have learned, but can be used to motivate people to “want to” learn. In a third study in 2009, by giving learners a way to see their deficits, they will be more motivated to work on those deficits.
